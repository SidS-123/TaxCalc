import React from 'react';
import DocumentUploader from '../components/DocumentUploader/DocumentUploader';

export default { title: 'DocumentUploader', component: DocumentUploader };

export const Default = () => <DocumentUploader />;
