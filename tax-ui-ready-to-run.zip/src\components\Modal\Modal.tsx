import React, { useEffect, useRef } from 'react';
import { trapFocus } from '../../utils/focusTrap';
import styles from './Modal.module.css';

export default function Modal({ title, open, onClose, children }: { title?: string; open: boolean; onClose: ()=>void; children: React.ReactNode; }) {
  const ref = useRef<HTMLDivElement|null>(null);

  useEffect(()=>{
    if(!open) return;
    const el = ref.current!;
    const remove = trapFocus(el);
    const onKey = (e:KeyboardEvent)=>{ if(e.key==='Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return ()=>{ remove(); document.removeEventListener('keydown', onKey); };
  },[open]);

  if(!open) return null;
  return (
    <div className={styles.overlay} role="dialog" aria-modal="true" aria-label={title || 'Modal'}>
      <div className={styles.panel} ref={ref}>
        <header className={styles.header}>
          <h2>{title}</h2>
          <button aria-label="Close modal" onClick={onClose}>✕</button>
        </header>
        <div className={styles.content}>{children}</div>
      </div>
    </div>
  );
}
