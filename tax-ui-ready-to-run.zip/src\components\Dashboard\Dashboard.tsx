import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import mockApi from '../../mock/mockApi';
import type { DashboardData } from '../../types/types';

// SVG Icons as React Components
const CheckIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
);

const AlertIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
  </svg>
);

const CircleIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
    <circle cx="12" cy="12" r="10" strokeWidth={2} />
  </svg>
);

const DollarIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="24" height="24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const TrendingUpIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="24" height="24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
  </svg>
);

const ProgressIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="24" height="24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
  </svg>
);

const UserIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
  </svg>
);

const FileTextIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
  </svg>
);

const ArrowRightIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
  </svg>
);

const InfoIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const XIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
);

// Tooltip Component
const Tooltip: React.FC<{ text: string; children: React.ReactNode }> = ({ text, children }) => {
  const [show, setShow] = useState(false);
  return (
    <div 
      className="tooltip-wrapper"
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      {children}
      {show && <div className="tooltip">{text}</div>}
    </div>
  );
};

// Modal Component
const Modal: React.FC<{ 
  title: string; 
  isOpen: boolean; 
  onClose: () => void; 
  children: React.ReactNode 
}> = ({ title, isOpen, onClose, children }) => {
  if (!isOpen) return null;
  
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="modal-close" onClick={onClose} aria-label="Close">
            <XIcon />
          </button>
        </div>
        <div className="modal-body">
          {children}
        </div>
      </div>
    </div>
  );
};


// Main Dashboard Component
const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [data, setData] = useState<DashboardData | null>(null);
  const [refundModalOpen, setRefundModalOpen] = useState(false);
  const [progressModalOpen, setProgressModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    mockApi.getDashboard()
      .then(setData)
      .catch((err) => {
        console.error('Failed to load dashboard:', err);
        setError('Failed to load dashboard data');
      })
      .finally(() => setLoading(false));
  }, []);

  const steps = [
    { id: 'personal', label: 'Personal Information', status: 'complete', icon: <UserIcon /> },
    { id: 'income', label: 'Income Documents', status: 'complete', icon: <FileTextIcon /> },
    { id: 'dependents', label: 'Dependents', status: 'warning', icon: <UserIcon /> },
    { id: 'deductions', label: 'Deductions & Adjustments', status: 'pending', icon: <FileTextIcon /> },
    { id: 'credits', label: 'Credits', status: 'pending', icon: <FileTextIcon /> },
    { id: 'review', label: 'Review & File Return', status: 'pending', icon: <FileTextIcon /> },
  ];

  const getStepIcon = (status: string) => {
    switch (status) {
      case 'complete':
        return <CheckIcon className="step-icon step-icon-complete" />;
      case 'warning':
        return <AlertIcon className="step-icon step-icon-warning" />;
      default:
        return <CircleIcon className="step-icon step-icon-pending" />;
    }
  };

  const handleStepClick = (stepId: string) => {
    if (stepId === 'income') navigate('/income');
    else if (stepId === 'deductions') navigate('/deductions');
    else if (stepId === 'dependents') navigate('/dependents');
    // Add navigation for other steps
  };

  // Use default data if still loading to show UI immediately
  const displayData = data || {
    incomeTotal: 0,
    refundEstimate: 0,
    progressPercent: 0,
    alerts: []
  };

  return (
    <>
      <style>{`
        * {
          box-sizing: border-box;
        }

        .dashboard-container {
          min-height: 100vh;
          background: #f8fafc;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif;
        }

        /* Main Content */
        .dashboard-main {
          margin-top: 64px;
          padding: 32px 24px;
          max-width: 1200px;
          margin-left: auto;
          margin-right: auto;
        }

        .dashboard-header {
          margin-bottom: 32px;
        }

        .dashboard-title {
          font-size: 36px;
          font-weight: 700;
          color: #111827;
          margin: 0 0 8px 0;
        }

        .dashboard-subtitle {
          font-size: 16px;
          color: #6b7280;
          margin: 0;
        }

        /* Primary CTA */
        .primary-cta {
          background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
          color: white;
          padding: 20px 24px;
          border-radius: 12px;
          margin-bottom: 32px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          cursor: pointer;
          transition: all 0.2s;
          box-shadow: 0 4px 6px -1px rgba(59, 130, 246, 0.3);
        }

        .primary-cta:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 12px -2px rgba(59, 130, 246, 0.4);
        }

        .primary-cta-content {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .primary-cta-text {
          font-size: 18px;
          font-weight: 600;
        }

        .primary-cta-arrow {
          color: white;
        }

        /* Summary Cards Grid */
        .summary-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          margin-bottom: 32px;
        }

        @media (max-width: 768px) {
          .summary-grid {
            grid-template-columns: 1fr;
          }
        }

        .summary-card {
          background: #ffffff;
          border: 1px solid #e5e7eb;
          border-radius: 12px;
          padding: 24px;
          cursor: pointer;
          transition: all 0.2s;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .summary-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
          border-color: #3b82f6;
        }

        .summary-card-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 12px;
        }

        .summary-card-title {
          font-size: 14px;
          font-weight: 600;
          color: #6b7280;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .summary-card-icon {
          color: #9ca3af;
        }

        .summary-card-value {
          font-size: 32px;
          font-weight: 700;
          color: #111827;
          margin: 0 0 8px 0;
        }

        .summary-card-value.positive {
          color: #10b981;
        }

        .summary-card-description {
          font-size: 13px;
          color: #9ca3af;
          margin: 0;
        }

        .progress-bar-container {
          margin: 16px 0;
        }

        .progress-bar {
          width: 100%;
          height: 8px;
          background: #e5e7eb;
          border-radius: 4px;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #3b82f6, #2563eb);
          border-radius: 4px;
          transition: width 0.3s ease;
        }

        .progress-text {
          font-size: 14px;
          font-weight: 600;
          color: #111827;
          margin-top: 8px;
        }

        /* Checklist Card */
        .checklist-card {
          background: #ffffff;
          border: 1px solid #e5e7eb;
          border-radius: 12px;
          padding: 24px;
          margin-bottom: 24px;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .checklist-title {
          font-size: 18px;
          font-weight: 700;
          color: #111827;
          margin: 0 0 20px 0;
        }

        .checklist-items {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .checklist-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 16px;
          background: #f9fafb;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s;
          border: 1px solid transparent;
        }

        .checklist-item:hover {
          background: #f3f4f6;
          border-color: #e5e7eb;
        }

        .step-icon {
          flex-shrink: 0;
        }

        .step-icon-complete {
          color: #10b981;
        }

        .step-icon-warning {
          color: #f59e0b;
        }

        .step-icon-pending {
          color: #d1d5db;
        }

        .checklist-item-content {
          flex: 1;
        }

        .checklist-item-label {
          font-size: 15px;
          font-weight: 600;
          color: #111827;
          margin: 0;
        }

        .checklist-item-status {
          font-size: 13px;
          color: #6b7280;
          margin-top: 4px;
        }

        /* Alerts */
        .alert-card {
          background: #fffbeb;
          border: 1px solid #fde68a;
          border-left: 4px solid #f59e0b;
          border-radius: 12px;
          padding: 20px;
          margin-bottom: 24px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .alert-card:hover {
          background: #fef3c7;
          border-color: #fbbf24;
        }

        .alert-header {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 8px;
        }

        .alert-icon {
          color: #f59e0b;
        }

        .alert-title {
          font-size: 16px;
          font-weight: 600;
          color: #92400e;
          margin: 0;
        }

        .alert-description {
          font-size: 14px;
          color: #78350f;
          margin: 0;
          padding-left: 32px;
        }

        /* AI Assistant Panel */
        .ai-assistant {
          position: fixed;
          bottom: 24px;
          right: 24px;
          width: 360px;
          background: #ffffff;
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
          z-index: 999;
          overflow: hidden;
        }

        .ai-assistant-header {
          background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
          color: white;
          padding: 16px 20px;
        }

        .ai-assistant-title {
          font-size: 16px;
          font-weight: 600;
          margin: 0;
        }

        .ai-assistant-body {
          padding: 20px;
        }

        .ai-assistant-greeting {
          font-size: 14px;
          color: #6b7280;
          margin-bottom: 16px;
          line-height: 1.6;
        }

        .ai-assistant-actions {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .ai-action-button {
          padding: 10px 16px;
          background: #f3f4f6;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          font-size: 14px;
          font-weight: 500;
          color: #111827;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }

        .ai-action-button:hover {
          background: #e5e7eb;
          border-color: #d1d5db;
        }

        /* Tooltip */
        .tooltip-wrapper {
          position: relative;
          display: inline-block;
        }

        .tooltip {
          position: absolute;
          bottom: 100%;
          left: 50%;
          transform: translateX(-50%);
          margin-bottom: 8px;
          padding: 8px 12px;
          background: #1f2937;
          color: white;
          font-size: 12px;
          border-radius: 6px;
          white-space: nowrap;
          z-index: 1000;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        .tooltip::after {
          content: '';
          position: absolute;
          top: 100%;
          left: 50%;
          transform: translateX(-50%);
          border: 4px solid transparent;
          border-top-color: #1f2937;
        }

        /* Modal */
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 2000;
          padding: 24px;
        }

        .modal-content {
          background: #ffffff;
          border-radius: 16px;
          max-width: 600px;
          width: 100%;
          max-height: 80vh;
          overflow-y: auto;
          box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }

        .modal-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 24px;
          border-bottom: 1px solid #e5e7eb;
        }

        .modal-header h2 {
          font-size: 20px;
          font-weight: 700;
          color: #111827;
          margin: 0;
        }

        .modal-close {
          background: none;
          border: none;
          cursor: pointer;
          color: #6b7280;
          padding: 4px;
          border-radius: 4px;
          transition: all 0.2s;
        }

        .modal-close:hover {
          background: #f3f4f6;
          color: #111827;
        }

        .modal-body {
          padding: 24px;
        }

        .modal-section {
          margin-bottom: 24px;
        }

        .modal-section-title {
          font-size: 14px;
          font-weight: 600;
          color: #6b7280;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 12px;
        }

        .modal-row {
          display: flex;
          justify-content: space-between;
          padding: 12px 0;
          border-bottom: 1px solid #f3f4f6;
        }

        .modal-row-label {
          color: #6b7280;
          font-size: 14px;
        }

        .modal-row-value {
          color: #111827;
          font-weight: 600;
          font-size: 14px;
        }

        .loading {
          display: flex;
          align-items: center;
          justify-content: center;
          min-height: 100vh;
          font-size: 16px;
          color: #6b7280;
        }

        @media (max-width: 768px) {
          .dashboard-main {
            padding: 24px 16px;
          }

          .dashboard-title {
            font-size: 28px;
          }

          .ai-assistant {
            width: calc(100% - 32px);
            right: 16px;
            bottom: 16px;
          }

        }
      `}</style>

      <div className="dashboard-container">
        {loading && (
          <div className="loading" style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 100 }}>
            Loading...
          </div>
        )}
        {error && (
          <div className="loading" style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 100, color: '#ef4444' }}>
            {error}
          </div>
        )}
        <main className="dashboard-main" style={{ opacity: loading ? 0.5 : 1, transition: 'opacity 0.3s' }}>
          {/* Dashboard Header */}
          <div className="dashboard-header">
            <h1 className="dashboard-title">Dashboard</h1>
            <p className="dashboard-subtitle">
              Here's a quick overview of your tax return and your next steps.
            </p>
          </div>

          {/* Primary CTA */}
          <div 
            className="primary-cta"
            onClick={() => handleStepClick('dependents')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && handleStepClick('dependents')}
          >
            <div className="primary-cta-content">
              <span className="primary-cta-text">
                Continue Your Tax Return → Step 3 of 6: Dependents
              </span>
            </div>
            <ArrowRightIcon className="primary-cta-arrow" />
          </div>

          {/* Summary Cards */}
          <div className="summary-grid">
            {/* Income Total Card */}
            <Tooltip text="Total of all income sources entered (W-2s, 1099s, etc.)">
              <div 
                className="summary-card"
                onClick={() => navigate('/income')}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === 'Enter' && navigate('/income')}
              >
                <div className="summary-card-header">
                  <span className="summary-card-title">Income Total</span>
                  <DollarIcon className="summary-card-icon" />
                </div>
                <p className="summary-card-value">
                  ${displayData.incomeTotal.toLocaleString()}
                </p>
                <p className="summary-card-description">
                  Based on W-2s and 1099s entered.
                </p>
              </div>
            </Tooltip>

            {/* Refund Estimate Card */}
            <Tooltip text="Estimated federal refund based on current entries and calculations">
              <div 
                className="summary-card"
                onClick={() => setRefundModalOpen(true)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === 'Enter' && setRefundModalOpen(true)}
              >
                <div className="summary-card-header">
                  <span className="summary-card-title">Refund Estimate</span>
                  <TrendingUpIcon className="summary-card-icon" />
                </div>
                <p className="summary-card-value positive">
                  ${displayData.refundEstimate.toLocaleString()}
                </p>
                <p className="summary-card-description">
                  Estimated federal refund so far.
                </p>
              </div>
            </Tooltip>

            {/* Progress Card */}
            <Tooltip text="Overall completion percentage of your tax return">
              <div 
                className="summary-card"
                onClick={() => setProgressModalOpen(true)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === 'Enter' && setProgressModalOpen(true)}
              >
                <div className="summary-card-header">
                  <span className="summary-card-title">Progress</span>
                  <ProgressIcon className="summary-card-icon" />
                </div>
                <div className="progress-bar-container">
                  <div className="progress-bar">
                    <div 
                      className="progress-fill" 
                      style={{ width: `${displayData.progressPercent}%` }}
                    />
                  </div>
                  <p className="progress-text">{displayData.progressPercent}% Complete</p>
                </div>
                <p className="summary-card-description">
                  Steps Overview
                </p>
              </div>
            </Tooltip>
          </div>

          {/* Checklist Card */}
          <div className="checklist-card">
            <h2 className="checklist-title">Your Tax Return Checklist</h2>
            <div className="checklist-items">
              {steps.map((step) => (
                <div
                  key={step.id}
                  className="checklist-item"
                  onClick={() => handleStepClick(step.id)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => e.key === 'Enter' && handleStepClick(step.id)}
                >
                  {getStepIcon(step.status)}
                  <div className="checklist-item-content">
                    <p className="checklist-item-label">{step.label}</p>
                    <p className="checklist-item-status">
                      {step.status === 'complete' && 'Completed'}
                      {step.status === 'warning' && 'Needs Info'}
                      {step.status === 'pending' && 'Not Started'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Alerts Section */}
          {displayData.alerts.length > 0 && (
            <div 
              className="alert-card"
              onClick={() => handleStepClick('dependents')}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && handleStepClick('dependents')}
            >
              <div className="alert-header">
                <AlertIcon className="alert-icon" />
                <h3 className="alert-title">{displayData.alerts[0].message}</h3>
              </div>
              <p className="alert-description">
                You need to add dependent information to maximize credits.
              </p>
            </div>
          )}
        </main>

        {/* AI Assistant Panel */}
        <div className="ai-assistant">
          <div className="ai-assistant-header">
            <h3 className="ai-assistant-title">AI Assistant</h3>
          </div>
          <div className="ai-assistant-body">
            <p className="ai-assistant-greeting">
              You're {displayData.progressPercent}% done. I can help you finish your return. 
              Need help with dependents?
            </p>
            <div className="ai-assistant-actions">
              <button 
                className="ai-action-button"
                onClick={() => handleStepClick('dependents')}
              >
                Fix Dependents
              </button>
              <button 
                className="ai-action-button"
                onClick={() => setRefundModalOpen(true)}
              >
                Explain Refund
              </button>
              <button 
                className="ai-action-button"
                onClick={() => setProgressModalOpen(true)}
              >
                Show Missing Items
              </button>
            </div>
          </div>
        </div>

        {/* Refund Breakdown Modal */}
        <Modal 
          title="Refund Calculation Breakdown"
          isOpen={refundModalOpen}
          onClose={() => setRefundModalOpen(false)}
        >
          <div className="modal-section">
            <div className="modal-row">
              <span className="modal-row-label">Total Income</span>
              <span className="modal-row-value">${displayData.incomeTotal.toLocaleString()}</span>
            </div>
            <div className="modal-row">
              <span className="modal-row-label">Standard Deduction</span>
              <span className="modal-row-value">-$14,600</span>
            </div>
            <div className="modal-row">
              <span className="modal-row-label">Taxable Income</span>
              <span className="modal-row-value">${(displayData.incomeTotal - 14600).toLocaleString()}</span>
            </div>
            <div className="modal-row">
              <span className="modal-row-label">Federal Tax Owed</span>
              <span className="modal-row-value">${((displayData.incomeTotal - 14600) * 0.12).toLocaleString()}</span>
            </div>
            <div className="modal-row">
              <span className="modal-row-label">Taxes Withheld</span>
              <span className="modal-row-value">${(displayData.incomeTotal * 0.15).toLocaleString()}</span>
            </div>
            <div className="modal-row" style={{ borderBottom: 'none', paddingTop: '16px', borderTop: '2px solid #e5e7eb' }}>
              <span className="modal-row-label" style={{ fontWeight: 700, fontSize: '16px' }}>Estimated Refund</span>
              <span className="modal-row-value" style={{ color: '#10b981', fontSize: '18px' }}>
                ${displayData.refundEstimate.toLocaleString()}
              </span>
            </div>
          </div>
        </Modal>

        {/* Progress Overview Modal */}
        <Modal 
          title="Steps Overview"
          isOpen={progressModalOpen}
          onClose={() => setProgressModalOpen(false)}
        >
          <div className="modal-section">
            <div className="checklist-items">
              {steps.map((step) => (
                <div
                  key={step.id}
                  className="checklist-item"
                  onClick={() => {
                    handleStepClick(step.id);
                    setProgressModalOpen(false);
                  }}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleStepClick(step.id);
                      setProgressModalOpen(false);
                    }
                  }}
                >
                  {getStepIcon(step.status)}
                  <div className="checklist-item-content">
                    <p className="checklist-item-label">{step.label}</p>
                    <p className="checklist-item-status">
                      {step.status === 'complete' && '✓ Completed'}
                      {step.status === 'warning' && '⚠ Needs Information'}
                      {step.status === 'pending' && '○ Not Started'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Modal>
      </div>
    </>
  );
};

export default Dashboard;

