========================================
Tax AI UI - Quick Start Guide
========================================

REQUIREMENTS:
- Node.js (version 18 or higher)
  Download from: https://nodejs.org/

HOW TO RUN:
1. Extract this zip file to any folder
2. Double-click START.bat
3. Wait for dependencies to install (first time only)
4. The UI will open automatically in your browser at http://localhost:5173

WHAT IT DOES:
- Starts a local development server
- Opens the Tax AI UI in your browser
- No internet required after initial setup (except for npm install)

TO STOP:
- Press Ctrl+C in the terminal window
- Or close the terminal window

TROUBLESHOOTING:
- If Node.js is not found: Install Node.js from nodejs.org
- If npm install fails: Check your internet connection
- If port 5173 is busy: The app will try the next available port (5174, 5175, etc.)

FILES INCLUDED:
- All source code in src/ folder
- Configuration files (package.json, vite.config.ts, etc.)
- START.bat - Run this to start the UI

NOTE: node_modules folder is NOT included to keep file size small.
It will be created automatically when you run START.bat for the first time.

========================================

