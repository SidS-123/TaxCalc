export function trapFocus(container: HTMLElement) {
  const focusable = container.querySelectorAll<HTMLElement>('a[href], button, textarea, input, select, [tabindex]:not([tabindex="-1"])');
  const first = focusable[0];
  const last = focusable[focusable.length - 1];

  function handleKey(e: KeyboardEvent) {
    if (e.key !== 'Tab') return;
    if (e.shiftKey) {
      if (document.activeElement === first) {
        e.preventDefault();
        (last || first).focus();
      }
    } else {
      if (document.activeElement === last) {
        e.preventDefault();
        (first || last).focus();
      }
    }
  }
  container.addEventListener('keydown', handleKey);
  return () => container.removeEventListener('keydown', handleKey);
}
