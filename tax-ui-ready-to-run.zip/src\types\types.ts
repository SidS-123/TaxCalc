export interface DocumentMeta {
  id: string;
  name: string;
  status: string;
  uploadedAt?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  isAdmin?: boolean;
}

export interface DashboardData {
  incomeTotal: number;
  refundEstimate: number;
  progressPercent: number;
  alerts: Array<{
    id: string;
    severity: string;
    message: string;
  }>;
}

export interface ReviewFlag {
  id: string;
  severity: string;
  field?: string;
  message: string;
}

export interface SummaryData {
  federalTax: number;
  stateTax: number;
  refund: number;
  due: number;
  effectiveRate: number;
  lastYearComparison: Array<{
    year: number;
    refund: number;
  }>;
}

