import React, { useState, useRef } from 'react';
import mockApi from '../../mock/mockApi';
import styles from './DocumentUploader.module.css';
import Modal from '../Modal/Modal';
import type { DocumentMeta } from '../../types/types';

export default function DocumentUploader() {
  const [docs, setDocs] = useState<DocumentMeta[]>([]);
  const [message, setMessage] = useState('');
  const [previewOpen, setPreviewOpen] = useState(false);
  const [selected, setSelected] = useState<DocumentMeta | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  async function handleFiles(files: FileList | null) {
    if (!files) return;
    for (const f of Array.from(files)) {
      const meta = await mockApi.uploadFile(f);
      setDocs((d) => [meta, ...d]);
    }
    setMessage("Document uploaded and queued for extraction. We'll notify you when extraction completes.");
  }

  async function extract(docId: string) {
    setMessage('Extracting...');
    try {
      const res = await mockApi.extractDocument(docId);
      setMessage('Extraction completed (mock).');
    } catch (e) {
      setMessage('Extraction failed. Please try again or upload a clearer copy.');
    }
  }

  function openPreview(d: DocumentMeta) {
    setSelected(d);
    setPreviewOpen(true);
  }

  return (
    <div className={styles.container}>
      <h2>Document Uploader</h2>
      <div className={styles.dropzone} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); handleFiles(e.dataTransfer.files); }}>
        <p>Drag & drop files here or</p>
        <button onClick={() => fileRef.current?.click()}>Select files</button>
        <input ref={fileRef} type="file" multiple hidden onChange={(e) => handleFiles(e.target.files)} />
      </div>
      <p aria-live="polite">{message}</p>
      <ul className={styles.list}>
        {docs.map((d) => (
          <li key={d.id}>
            <span>{d.name}</span>
            <span className={styles.badge}>{d.status}</span>
            <button onClick={() => extract(d.id)}>Extract Data</button>
            <button onClick={() => openPreview(d)}>Preview</button>
          </li>
        ))}
      </ul>

      <Modal title="Preview" open={previewOpen} onClose={() => setPreviewOpen(false)}>
        {selected ? <div><p>Name: {selected.name}</p><p>Status: {selected.status}</p></div> : <div>No document selected</div>}
      </Modal>
    </div>
  );
}
