import React, { useState } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import Dashboard from './components/Dashboard/Dashboard';
import DocumentUploader from './components/DocumentUploader/DocumentUploader';
import './App.css';

// NavBar Icons
const UserIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
  </svg>
);

const ChevronDownIcon = ({ className = '' }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
  </svg>
);

// Navigation Bar Component
const NavBar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const navItems = [
    { path: '/', label: 'Dashboard' },
    { path: '/documents', label: 'Documents' },
    { path: '/income', label: 'Income' },
    { path: '/deductions', label: 'Deductions' },
  ];

  return (
    <>
      <style>{`
        .navbar {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          background: #ffffff;
          border-bottom: 1px solid #e5e7eb;
          z-index: 1000;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .navbar-content {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 64px;
        }

        .navbar-left {
          display: flex;
          align-items: center;
          gap: 32px;
        }

        .navbar-logo {
          font-size: 20px;
          font-weight: 700;
          color: #3b82f6;
          background: none;
          border: none;
          cursor: pointer;
          padding: 0;
        }

        .navbar-links {
          display: flex;
          gap: 8px;
        }

        .navbar-link {
          padding: 8px 16px;
          background: none;
          border: none;
          color: #6b7280;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          border-radius: 6px;
          transition: all 0.2s;
        }

        .navbar-link:hover {
          background: #f3f4f6;
          color: #111827;
        }

        .navbar-link.active {
          background: #eff6ff;
          color: #3b82f6;
          font-weight: 600;
        }

        .navbar-right {
          display: flex;
          align-items: center;
        }

        .user-menu-wrapper {
          position: relative;
        }

        .user-menu-button {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 12px;
          background: #f9fafb;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          cursor: pointer;
          font-size: 14px;
          color: #111827;
          transition: all 0.2s;
        }

        .user-menu-button:hover {
          background: #f3f4f6;
        }

        .user-icon {
          color: #6b7280;
        }

        .chevron-icon {
          color: #9ca3af;
        }

        .user-menu-dropdown {
          position: absolute;
          top: calc(100% + 8px);
          right: 0;
          background: #ffffff;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
          min-width: 160px;
          padding: 4px;
          z-index: 1001;
        }

        .user-menu-item {
          width: 100%;
          padding: 10px 16px;
          text-align: left;
          background: none;
          border: none;
          color: #111827;
          font-size: 14px;
          cursor: pointer;
          border-radius: 4px;
          transition: background 0.2s;
        }

        .user-menu-item:hover {
          background: #f3f4f6;
        }

        @media (max-width: 768px) {
          .navbar-content {
            padding: 0 16px;
          }

          .navbar-links {
            display: none;
          }
        }
      `}</style>
      <nav className="navbar">
        <div className="navbar-content">
          <div className="navbar-left">
            <button className="navbar-logo" onClick={() => navigate('/')}>
              Tax AI
            </button>
            <div className="navbar-links">
              {navItems.map(item => (
                <button
                  key={item.path}
                  className={`navbar-link ${location.pathname === item.path ? 'active' : ''}`}
                  onClick={() => navigate(item.path)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
          <div className="navbar-right">
            <div className="user-menu-wrapper">
              <button 
                className="user-menu-button"
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                aria-expanded={userMenuOpen}
              >
                <UserIcon className="user-icon" />
                Demo User
                <ChevronDownIcon className="chevron-icon" />
              </button>
              {userMenuOpen && (
                <div className="user-menu-dropdown">
                  <button className="user-menu-item">Profile</button>
                  <button className="user-menu-item">Sign out</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};

function Documents() {
  return (
    <div className="page" style={{ marginTop: '64px', padding: '32px 24px', maxWidth: '1200px', marginLeft: 'auto', marginRight: 'auto' }}>
      <DocumentUploader />
    </div>
  );
}

function Income() {
  return (
    <div className="page" style={{ marginTop: '64px', padding: '32px 24px', maxWidth: '1200px', marginLeft: 'auto', marginRight: 'auto' }}>
      <h1>Income</h1>
      <p>Income management page. Plug your income code here.</p>
    </div>
  );
}

function Deductions() {
  return (
    <div className="page" style={{ marginTop: '64px', padding: '32px 24px', maxWidth: '1200px', marginLeft: 'auto', marginRight: 'auto' }}>
      <h1>Deductions</h1>
      <p>Deductions management page. Plug your deductions code here.</p>
    </div>
  );
}

function Dependents() {
  return (
    <div className="page" style={{ marginTop: '64px', padding: '32px 24px', maxWidth: '1200px', marginLeft: 'auto', marginRight: 'auto' }}>
      <h1>Dependents</h1>
      <p>Dependents management page. Plug your dependents code here.</p>
    </div>
  );
}

export default function App() {
  return (
    <div className="app">
      <NavBar />
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/documents" element={<Documents />} />
        <Route path="/income" element={<Income />} />
        <Route path="/deductions" element={<Deductions />} />
        <Route path="/dependents" element={<Dependents />} />
      </Routes>
    </div>
  );
}

