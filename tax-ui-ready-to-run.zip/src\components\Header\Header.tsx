import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Header.module.css';

export default function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className={styles.header}>
      <a className={styles.skip} href="#main">Skip to content</a>
      <div className={styles.left}>
        <Link to="/" className={styles.logo}>Tax AI</Link>
        <nav aria-label="Main navigation" className={styles.nav}>
          <Link to="/">Dashboard</Link>
          <Link to="/documents">Documents</Link>
          <Link to="/income">Income</Link>
          <Link to="/deductions">Deductions</Link>
        </nav>
      </div>
      <div className={styles.right}>
        <button aria-haspopup="true" aria-expanded={open} aria-controls="user-menu" onClick={()=>setOpen(o=>!o)} aria-label="Open user menu" className={styles.userBtn}>
          Demo User ▾
        </button>
        {open && (
          <div id="user-menu" role="menu" className={styles.menu}>
            <button role="menuitem">Profile</button>
            <button role="menuitem">Sign out</button>
          </div>
        )}
      </div>
    </header>
  );
}
