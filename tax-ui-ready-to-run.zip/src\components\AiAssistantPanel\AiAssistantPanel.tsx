import React, { useState } from 'react';
import mockApi from '../../mock/mockApi';
import styles from './AiAssistantPanel.module.css';
import { motion, AnimatePresence } from 'framer-motion';

export default function AiAssistantPanel() {
  const [messages, setMessages] = useState([{ id: 'm0', sender: 'assistant', text: 'Hello! Ask me about your return.', createdAt: new Date().toISOString() }]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);

  async function send() {
    if (!text) return;
    const userMsg = { id: 'u' + Date.now(), sender: 'user', text, createdAt: new Date().toISOString() };
    setMessages((m) => [...m, userMsg]);
    setLoading(true);
    try {
      const reply = await mockApi.sendAiMessage(text);
      setMessages((m) => [...m, reply]);
    } finally {
      setLoading(false);
      setText('');
    }
  }

  return (
    <aside className={styles.panel} aria-label="AI assistant">
      <h4>AI Assistant</h4>
      <div className={styles.messages} aria-live="polite" role="log" aria-atomic="false">
        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <motion.div key={m.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className={m.sender === 'assistant' ? styles.assistant : styles.user}>
              <span className={styles.label}>{m.sender}</span>
              <div>{m.text}</div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
      <div className={styles.controls}>
        <input aria-label="Message" value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') send(); }} />
        <button onClick={send} disabled={loading || !text}>{loading ? '...' : 'Send'}</button>
      </div>
    </aside>
  );
}
