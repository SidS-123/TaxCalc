import dashboardData from './data/dashboard.json';
import userProfile from './data/userProfile.json';
import reviewFlags from './data/reviewFlags.json';
import lastYearSummary from './data/lastYearSummary.json';

const delay = (min=50,max=150) => new Promise(r=>setTimeout(r, Math.random()*(max-min)+min));

export const mockApi = {
  async getDashboard(){ await delay(); return dashboardData; },
  async uploadFile(file){ await delay(); return { id:'doc-'+Date.now(), name:file.name, status:'uploaded', uploadedAt:new Date().toISOString() }; },
  async listDocuments(){ await delay(); return []; },
  async extractDocument(id){ await delay(); return { documentId:id, fields:{}}; },
  async sendAiMessage(message){ await delay(); return { id:'m-'+Date.now(), sender:'assistant', text:'Mock reply to: '+message, createdAt:new Date().toISOString() }; },
  async getIncome(){ await delay(); return [{ id:'i1', type:'W-2', source:'Acme', amount:60000, date:'2024-01-01' }]; },
  async saveIncome(item){ await delay(); return { ...item, id:item.id||('i-'+Date.now()) }; },
  async parseCsv(file){ await delay(); return []; },
  async getDeductions(){ await delay(); return []; },
  async getReviewFlags(){ await delay(); return reviewFlags; },
  async autoFixFlag(id){ await delay(); return { success:true }; },
  async getSummary(){ await delay(); return lastYearSummary; },
  async efileReturn(){ await delay(); return { receiptId:'RCPT-'+Date.now(), status:'submitted' }; },
  async getUserProfile(){ await delay(); return userProfile; }
}
export default mockApi;
