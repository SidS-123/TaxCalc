# GPT5 Tax UI — Ultimate Mock

This repository is an enhanced frontend UI mock for a Tax AI app (React + TypeScript + Vite).
It includes accessibility improvements, focus-trap modal, animated AI assistant, Storybook, Vitest, and more.

## Highlights added in this "ultimate" build

- Focus-trap Modal component (keyboard accessible + Escape to close)
- Framer Motion animations for AI assistant messages
- Storybook stories for Header and DocumentUploader
- Vitest configuration for fast unit tests
- Husky & lint-staged pre-commit hooks
- Better ARIA attributes and keyboard navigation hooks

## Quick start

1. Install:
   ```bash
   npm install
   ```

2. Run dev server:
   ```bash
   npm run dev
   ```

3. Run Storybook:
   ```bash
   npm run storybook
   ```

4. Run vitest unit tests:
   ```bash
   npm run test:unit
   ```

## Integration

Replace functions in `src/mock/mockApi.ts` with your real services. See the original spec for integration points.

