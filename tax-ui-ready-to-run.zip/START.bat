@echo off
echo ========================================
echo Tax AI UI - Starting...
echo ========================================
echo.

REM Get the directory where this batch file is located
set SCRIPT_DIR=%~dp0

REM Navigate to the script directory
cd /d "%SCRIPT_DIR%"

echo Checking for Node.js...
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Node.js is not installed!
    echo.
    echo Please install Node.js from: https://nodejs.org/
    echo Then run this batch file again.
    echo.
    pause
    exit /b 1
)

echo Node.js found!
echo.

REM Check if node_modules exists, if not install dependencies
if not exist "node_modules" (
    echo node_modules not found. Installing dependencies...
    echo This may take a few minutes on first run...
    echo.
    call npm install
    if %ERRORLEVEL% NEQ 0 (
        echo.
        echo ERROR: npm install failed!
        echo Please check your internet connection and try again.
        echo.
        pause
        exit /b 1
    )
    echo.
    echo Dependencies installed successfully!
    echo.
) else (
    echo Dependencies already installed.
    echo.
)

REM Start the React/Vite dev server
echo ========================================
echo Starting Tax AI UI...
echo ========================================
echo.
echo The UI will open in your browser automatically.
echo If it doesn't, go to: http://localhost:5173
echo.
echo Press Ctrl+C to stop the server.
echo.
echo ========================================
echo.

npm run dev

